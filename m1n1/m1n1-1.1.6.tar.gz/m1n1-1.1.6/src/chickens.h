/* SPDX-License-Identifier: MIT */

#ifndef __CHICKENS_H__
#define __CHICKENS_H__

const char *init_cpu(void);

#endif
