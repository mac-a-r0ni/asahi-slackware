/* SPDX-License-Identifier: MIT */

#ifndef PCIE_H
#define PCIE_H

int pcie_init(void);
int pcie_shutdown(void);

#endif
