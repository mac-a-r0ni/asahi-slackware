/* SPDX-License-Identifier: MIT */

#ifndef __CLK_H__
#define __CLK_H__

void clk_init(void);

#endif
