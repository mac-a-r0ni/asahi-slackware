/* SPDX-License-Identifier: MIT */

#ifndef DAPF_H
#define DAPF_H

int dapf_init_all(void);
int dapf_init(const char *path);

#endif
