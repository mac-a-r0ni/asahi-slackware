/* SPDX-License-Identifier: MIT */

#ifndef __PAYLOAD_H__
#define __PAYLOAD_H__

int payload_run(void);

#endif
