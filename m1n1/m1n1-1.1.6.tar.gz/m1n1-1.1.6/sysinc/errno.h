/* SPDX-License-Identifier: MIT */

#ifndef ERRNO_H
#define ERRNO_H

#define ENOMEM 12
#define EINVAL 22

#endif
