These fonts have been generated with
	makefont.sh 8 16 12 SourceCodePro-Bold.ttf font.bin 
	makefont.sh 16 32 25 SourceCodePro-Bold.ttf font_retina.bin
